package MActionEventDemo;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class CashSystem extends JFrame{
	
	public static final int WIDTH=400,HIGHT=400;
	private JLabel showResult;
	private JButton confirm,cancel;
	private JTextField price,number;
	private double total=0.0;
	private JComboBox method;
	private JTextArea showArea;
	private JScrollPane jShowArea;

 
	public void startFrame()
	{
		this.setTitle("�̳�����ϵͳ");
		Dimension d=this.getToolkit().getScreenSize();
		this.setLocation((d.width-WIDTH)/2, (d.height-HIGHT)/2);
		this.setSize(WIDTH, HIGHT);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		
		JPanel v1=new JPanel();
		BoxLayout b1=new BoxLayout(v1,BoxLayout.Y_AXIS);
		v1.setLayout(b1);
		v1.add(new JLabel("���ۣ�"));
		v1.add(new JLabel("������"));
		v1.add(new JLabel("���㷽ʽ��"));
		JPanel v2=new JPanel();
		BoxLayout b2=new BoxLayout(v2,BoxLayout.Y_AXIS);
		v2.setLayout(b2);
		price=new JTextField(15);
		number=new JTextField(15);
		String []items={"�����շ�","��8��","��5��","��300��100"};
		method=new JComboBox(items);
		v2.add(price);
		v2.add(number);
		v2.add(method);
		JPanel v3=new JPanel();
		BoxLayout b3=new BoxLayout(v3,BoxLayout.Y_AXIS);
		v3.setLayout(b3);
		confirm=new JButton("ȷ��");
		cancel=new JButton("����");
		v3.add(confirm);
		v3.add(cancel);
		JPanel h=new JPanel();
		BoxLayout b4=new BoxLayout(h,BoxLayout.X_AXIS);
		h.setLayout(b4);
		h.add(v1);
		h.add(v2);
		h.add(v3);
		showArea=new JTextArea(6,15);
		jShowArea =new JScrollPane(showArea);
        showResult=new JLabel("��ʾ�ܼ�");
        confirm.addActionListener(new ConfirmHanlder());
        cancel.addActionListener(new ActionListener()
        {
        	public void actionPerformed(ActionEvent e)
        	{
        		price.setText(null);
        		number.setText(null);
        		showArea.setText(null);
        		showResult.setText(null);
        	}
        });
        this.add(h,"North");
        this.add(jShowArea,"Center");
        this.add(showResult,"South");
        
        this.setVisible(true);
        
	
		
		
		
		
	}
	class ConfirmHanlder implements ActionListener
	{
		double totalPrice=0.0;
		public void actionPerformed(ActionEvent e)
		{
			String condition="�����շ�";
			
			switch(method.getSelectedIndex())
			{
			case 0:
				totalPrice=getCash(1);
				condition="�����շ�";
				break;
			case 1:
				totalPrice=getCash(0.8);
				condition="��8�ۣ�";
				break;
			case 2:
				totalPrice=getCash(0.5);
				condition="��5�ۣ�";
				break;
			case 3:
				totalPrice=getCash(300,100);
				condition="��300��100";
				break;
				
			}
			total =total+totalPrice;
			showArea.append(condition+"--���ۣ�"+price.getText()+"������"+number.getText()+"�ϼƣ�"+totalPrice+"\n");
			showResult.setFont(new Font("����",Font.ITALIC,20));
			showResult.setText("�ܼƣ�"+total+"Ԫ");
			
			
		}
		private double getCash(double rate)
		{
			return Double.parseDouble(price.getText())*Integer.parseInt(number.getText())*rate;
		}
		private double getCash(int MoneyCondition,int MoneyReturn)
		{
		 double money;
		 money=Double.parseDouble(price.getText())*Integer.parseInt(number.getText());
		 if(money>MoneyCondition)
		 {
			 return money-(int)money/MoneyCondition*MoneyReturn;
			 
		 }
		 else
		 {
			 return money;
		 }
		}
	}
	
	public static void main(String[] args) {
		CashSystem cs=new CashSystem();
		cs.startFrame();
		// TODO �Զ����ɵķ������

	}

}
